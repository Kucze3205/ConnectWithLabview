cd "$(dirname "$0")/tree"
bash -c 'python3 policy/evaluator/evaluate.py --check'
