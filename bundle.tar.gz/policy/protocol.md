# Work rules

These local layer work rules are maintained by the Policymaker. The engine's
session contract takes precedence.

Read the whole task and the files named in its context budget. Start from named evidence;
expand the investigation when the task needs it. When measuring or researching, report the
finding before proposing a fix.

Keep the report concise; link detailed evidence and explain what should happen next.

Before planning or implementing the LabVIEW reader, follow `docs/perpetua/evaluation.md`.
Prepare the repeatable verification method first. Product implementation waits until an independent review
has checked that method and the owner has accepted the pinned protocol and evidence through the existing change gate.
An evidence index, a green engine test suite or a functioning export does not establish benchmark readiness.
Keep missing coverage and unmeasured quality explicit in every evaluation report.

Before private-data use, disclosure, publication or new resource spending, read
`docs/perpetua/accepted-limits.md`. Request optional private access through a
`capability` proposal while continuing ready work. Plan resource-dependent tasks
only after readiness; an open access request must not hold an iteration open.

Aim for about 15 lines of report prose: what changed and why, or exactly what failed.
Use `## Discoveries` for findings outside the task, one sentence and evidence link each.
For unfinished work include `## What next`: saved work, the next step, and what
the next cold session should avoid repeating. Put lengthy evidence in linked files.
