# Work rules

These local layer work rules are maintained by the Policymaker. The engine's
session contract takes precedence.

Read the whole task and the files named in its context budget. Start from named evidence;
expand the investigation when the task needs it. When measuring or researching, report the
finding before proposing a fix.

Keep the report concise; link detailed evidence and explain what should happen next.

Aim for about 15 lines of report prose: what changed and why, or exactly what failed.
Use `## Discoveries` for findings outside the task, one sentence and evidence link each.
For unfinished work include `## What next`: saved work, the next step, and what
the next cold session should avoid repeating. Put lengthy evidence in linked files.
