# Session context

The Policymaker and shaper start from a compact `loop-state.json`: current facts,
the previous Iteration's outcome and a history pointer. The engine still computes
`no_progress` from the full history and retains full snapshots and immutable records.
The state comment is omitted from `issue.md`.

`policy/session-state.py` builds `loop-state.json` and the files under `.session/history/` for every role. The engine writes
the facts (the stored state and the records and report snapshots the role may see) and runs the script in the tokenless job;
the answer is `{"loop_state": {...}|null, "files": {"history/...": "text"}}` (at most 8 MB). Invalid output fails the
iteration and rolls `execution/` and `policy/` back. A change to the script reaches sessions staged after it is accepted.

## Three ways to reach history

1. **Working memory** carries the current approach, open threads, attempts and
   reasons, with exact sources and an indication of which results it considers.
   Initially the Policymaker maintains `policy/working-memory.md` and the shaper
   maintains `journal/working-memory.md`; other roles report findings. Update in
   an existing Session when understanding changes. Memory may be stale, including
   after rollback; use current state and sources to resolve discrepancies.
2. **Searchable Session documents** live at `.session/history/sessions/<issue>/`.
   `task.md` has task metadata, results and task text. `<snapshot>.md` has a factual
   header and the original report with real line breaks. Use Grep/Glob to find
   filenames or short matches, then Read selected sections. Chronology is a filter,
   not a prerequisite for finding work.
3. **Records and exact snapshots** provide detail. Prepared Iteration records live
   at `.session/history/records/<iteration>.json`. Report documents retain their
   source URL and body hash. `reports/index.json` lists the current reports; a stored snapshot is not automatically current.

`.session/history/manifest.json` describes scope, checkout and counts, not every
entry. No match is not proof that something was never attempted. See
[reports](session-reports.md) and [exports](session-exports.md) for source semantics.
The Policymaker and shaper default to all permitted history in the prepared checkout.
Other roles receive task-selected inputs.

## Declarations controlled by the Policymaker

Role `SKILL.md` frontmatter may declare concrete workspace-relative startup paths:

```yaml
startup:
  - .session/loop-state.json
  - .session/capabilities.json
  - journal/working-memory.md
  - .session/role/references/current-method.md
```

The engine includes its contract/bootstrap, task and role skill. One resolved list
generates startup Read instructions and the estimate; file aliases count
once. Further references are read when needed. Remove duplicate unconditional Read
instructions from role prose/prompts. Paths select allowed recipient files, not
commands, globs, parent traversal or Git internals. Missing files are diagnostics.

Without `startup`, existing staged state/capabilities/Policymaker prompt and working
memory (when present for Policymaker/shaper) are initial reads. The Policymaker can
replace these defaults, including its own. Its own profile stays engine-owned.

Skill frontmatter may also supply default `exports` using the existing selectors.
An explicit issue declaration takes precedence. Either declaration changes the
Policymaker/shaper's archive scope to task-selected inputs; `exports: []` opts out
of the full archive view. Mandatory current inputs
remain independent. Memory organization and authorship are mutable policy choices.

## Nonblocking startup budget

Every model Session gets `.session/startup.json`: model, estimate,
document paths/hashes/byte sizes and `ok`, `over_budget` or `unmeasured` status.
`startup_token_warning` of `policy/params.yml` defaults to 100000, a warning threshold
and not a target. Script-only sessions have no token budget.

`policy/session-startup.py` makes the estimate, locally: 4 bytes per token, from the
contract, bootstrap and declared documents. No provider call is made and no API key is
needed. The engine shows the script the files the recipient may read and checks what it
returns (reads it was shown, a prompt, a status). The script also builds the
bootstrap prompt and the warning lines the session sees, so the Policymaker can change
them. Diagnostic output, CLI internals and later reads are excluded. It is not full
active-context usage or a guarantee about model quality.

Nontext documents and missing declared files produce `unmeasured`. Over-budget estimates
and notification failures never stop the Session. A script that prints invalid data fails
the iteration like the other policy scripts; a loop without the script has no bootstrap or budget.

The Session sees a warning and the Policymaker receives it at its next permitted
Session, at an Iteration boundary. One active incident per role updates without
repeated policy triggers after a successful Policymaker Session has received it.
An unsuccessful Session leaves its notices pending. Successful measurement clears
the incident; recurrence triggers again. Policymaker sees its own warning directly.
Immutable Iteration summaries
retain startup size/status independently of later incident resolution.

## Routed sessions: what the model receives each turn (this loop)

A routed session (`role_runtime.py`) sends one request per turn, built from the role prompt, the action schema, the role profile and the continuation:

- **Whole history, never cut:** every earlier turn goes in full, with its action and outcome, one block per turn. The history only grows at its end, so each request extends the previous one and the prompt cache reads all of it except the newest turn.
- **Budget in unique input tokens:** the session ends as `partial` (`reason: input_budget`) when the input it has paid for reaches `context.input_tokens` (800 000): `in` plus `cache_write` for Claude, `in` minus `cache_read` plus `cache_write` for Codex and Copilot, or the largest request divided by 4 when a provider reports no usage. Turns count only against the `max_turns` safety cap.
- **Claude's prompt cache:** Claude gets the stable parts as a system prompt file and the continuation as separate blocks of one stream-json message: one per turn, nothing after the newest turn. Each CLI process uses the same working directory, because the CLI writes that path into its system prompt. Codex and Copilot get everything as one text.

`policy/params.yml` `context.input_tokens` sets the budget; the Policymaker cannot exceed `engine.yml` `context_ceilings.input_tokens` (800 000), which stays under the model's context window. Each request's size is added to the session's `requests.<provider>/<model>` (`count`, `bytes`, `max_bytes`) next to `usage`, so an audit can compare models by bytes per turn.
