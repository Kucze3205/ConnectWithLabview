#!/usr/bin/env bash
# One session. Started from $RUNNER_TEMP/trusted: the engine checkout is not on the disk while it runs.
# Input: $WORK/.session/ (put there by `loop.py stage`). Output: $WORK/.session/report.md, published by the epilogue.
# The agent has no `gh`, no push credentials and no GitHub token; its Claude credential lives only in the claude process.
set -u
TRUSTED="$(cd "$(dirname "$0")" && pwd)"
OUT="${RUNNER_TEMP:-/tmp}"
cd "$WORK" || exit 1
git config user.name "github-actions[bot]"
git config user.email "41898282+github-actions[bot]@users.noreply.github.com"
git checkout -q -B "task/$ISSUE"
date +%s > "$OUT/agent-start"

# Secrets: `resolve` only proves an approved name has a line in the pool, not that the repository secret has a value.
# `stage` writes the approved names (from the frozen consent) to $TRUSTED/secrets; an empty one stops the start before
# any agent code runs, and the epilogue turns the marker into `blocked: secret-missing:NAME`. Unapproved pool names
# need no unsetting here: the workflow expression already gives them empty.
while read -r name; do
  if [ -n "$name" ] && [ -z "${!name:-}" ]; then
    echo "$name" > "$OUT/secret-missing"
    echo 1 > "$OUT/agent-exit"
    date +%s > "$OUT/agent-end"
    exit 0
  fi
done < "$TRUSTED/secrets"

if [ "$KIND" = script ]; then
  # a deterministic role: no model, no credential
  unset CLAUDE_CODE_OAUTH_TOKEN GH_TOKEN GITHUB_TOKEN
  timeout "${AGENT_TIMEOUT}m" bash "$TRUSTED/command.sh" > "$OUT/script-output.txt" 2>&1
  echo $? > "$OUT/agent-exit"
  cat "$OUT/script-output.txt"
  date +%s > "$OUT/agent-end"
  exit 0
fi

AVAILABLE_TOOLS="$(cat "$TRUSTED/tools")"

# the end of a turn in -p is the end of the session: background work and Monitor die with the runner
export CLAUDE_CODE_DISABLE_BACKGROUND_TASKS=1
# API overload (429/529) is retried instead of ending the session; stream_filter.py ends it on a rejected limit event
export CLAUDE_CODE_RETRY_WATCHDOG=1
# long work in the foreground: by default Bash cuts off after 2 min
export BASH_DEFAULT_TIMEOUT_MS=$((AGENT_TIMEOUT * 60000)) BASH_MAX_TIMEOUT_MS=$((AGENT_TIMEOUT * 60000))
export SESSION_END=$(( $(date +%s) + AGENT_TIMEOUT * 60 ))
TOKEN="${CLAUDE_CODE_OAUTH_TOKEN:-}"
unset CLAUDE_CODE_OAUTH_TOKEN GH_TOKEN GITHUB_TOKEN

# the prompt goes through stdin: an argument over 128 KiB fails with E2BIG
CLAUDE_CODE_OAUTH_TOKEN="$TOKEN" timeout "${AGENT_TIMEOUT}m" claude -p \
  --model "$MODEL" --effort "$EFFORT" \
  --permission-mode acceptEdits --allowedTools "$TOOLS" --disallowedTools Monitor \
  --tools "$AVAILABLE_TOOLS" --strict-mcp-config --mcp-config "$TRUSTED/mcp.json" \
  --disable-slash-commands \
  --setting-sources '' --append-system-prompt-file "$TRUSTED/contract.md" \
  --settings "$TRUSTED/settings.json" \
  --max-turns "$MAX_TURNS" --output-format stream-json --verbose \
  < "$TRUSTED/prompt.md" 2> "$OUT/claude-stderr.txt" \
  | python3 "$TRUSTED/stream_filter.py" "$OUT"
echo "${PIPESTATUS[0]}" > "$OUT/agent-exit"
date +%s > "$OUT/agent-end"
exit 0
