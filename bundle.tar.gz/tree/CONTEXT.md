# Perpetua

A Claude Code plugin that sets up an autonomous agent loop in a repository and
leaves it running until it reaches its goal. The goal is not limited to code.

## Language

**Loop**:
A self-sustaining chain of iterations in GitHub Actions that works toward a
goal without a human driving it. Switched on and off only by the owner.

**Owner**:
The human the loop works for. The only one who arms the loop, accepts a goal
gate, and approves what the loop's policy reserves for them.
_Avoid_: user, operator

**Setup map**:
The wayfinder map that connects a clarified goal to an initial approach and the
environment the loop needs to pursue it; closing it arms the loop.
_Avoid_: onboarding, wizard

**Engine**:
The goal-independent machinery of a loop: workflows, scripts, configuration,
the policymaker's prompt. Copied into the loop's repository by setup, where it
belongs to that loop; a setup map may change it. Changed only by the owner.
_Avoid_: framework, runtime

**Role**:
A pair of skill + permission profile, selected by a label on an issue. Built
per loop during setup, preferably from existing skills; installed as a complete
local copy in one layer (`execution/` or `policy/`).
_Avoid_: persona, agent type

**Goal**:
The outcome the loop works toward, with a clear scope and verifiable success
criteria and evidence; numerical metrics are optional. Only the owner accepts
the goal and its reformulations.

**Initial approach**:
A revisable plan of how the loop could reach the goal: steps, dependencies and
unknowns from which its environment requirements follow.

**Goal gate**:
The check that decides the goal is reached. Without an owner-accepted gate the
loop cannot declare its own end.
_Avoid_: success metric, stop condition

**Iteration**:
One unit of the loop's work: a plan executed as one or more parallel jobs,
ending in a verdict on what it produced. Exploring a wrong solution counts.
_Avoid_: cycle

**Session**:
One agent run in one job, working one issue under one role. An iteration is
made of sessions.
_Avoid_: run

**Iteration core**:
The part of an iteration that actually moves the loop toward the goal: the
work done by the roles (building, researching, verifying, exploring).
_Avoid_: step, task

**Iteration record**:
The immutable account of one iteration, written by the engine when the
iteration ends, closed or failed: its starting state, the tasks as planned,
and the outcome (verdict, token use, wall time, resources).
The last good state is the last closed one.
_Avoid_: log, report

**Policy**:
The rules and artifacts the policymaker creates and maintains to govern the
implementation layer: work rules, role instructions, profiles, parameters and
evaluation rules.
_Avoid_: agent, policymaker

**Policymaker**:
The agent in the policy layer that manages the loop's architecture by creating
and revising policy; it does not perform the implementation layer's work.
_Avoid_: policy, politician, strategy, scheduler

**Policy layer** (directory `policy/`):
The part of the loop in which the policymaker defines how the implementation
layer works, within the owner's accepted limits. Holds the Policymaker's skill,
audit, evaluator maintenance, the evaluator verifier, parameters and the
measurement.

**Implementation layer** (also *execution layer*, directory `execution/`):
The part of the loop that applies policy to plan, execute and evaluate work
toward the goal. Holds the shaper and the goal roles; its sessions do not see
the inside of policy.

**Managed definitions**:
The version-controlled definitions the engine stages, admits and rolls back as
one revision: per layer `profiles.yml`, `roles/<role>/`, `protocol.md` and
`prompts/role.md`, plus the shared `policy/params.yml` and the evaluator. Layer
is assigned by location, never by a field. Inactive candidates stay in
`templates/` and are not roles.

**Role template**:
An inactive starting skill or profile under `templates/`, or `ROLE-TEMPLATE.md`.
Setup copies a template (or an existing skill) into a layer and adapts the copy;
the template itself never runs.

**Orchestrator**:
A role that turns the goal and the loop's state into concrete work: what to
analyse, build, search, whom to bring in. Decides what the loop does today;
may propose changes to its own prompt, which the policymaker judges. The
policymaker may replace it with a deterministic rule or remove it.
_Avoid_: manager

**Shaper**:
The orchestrator, or a script role acting as a deterministic rule: whatever turns
the goal and the loop's state into a task graph. It writes the graph to a file; the
engine creates the issues. It has no GitHub credentials.
_Avoid_: planner, scheduler

**Task graph**:
The tasks of one iteration with their blocking edges, as issues. Its width is the
number of tasks in the largest dependency-depth level, computed from the graph,
not set. It is a structural statistic, not a cap or prediction of concurrent jobs.

**Policy artifacts**:
The version-controlled parts of policy maintained by the policymaker: the
orchestrator's prompt, role skills, profiles, parameters, a deterministic rule
and the evaluator.

**Evaluator**:
The measurement that tells whether work moved the loop toward the goal: a
script, which may call a model. Its verdict feeds the change gate. The work it
measures can never change it, only suggest a change to the policymaker.
_Avoid_: benchmark, progress tests

**Evaluator verifier**:
An independent session that checks a change to the evaluator before it takes
effect: does the changed evaluator still measure progress toward the goal.

**Audit**:
A role the policymaker orders to learn and monitor the loop's whole environment,
every session included: what the loop consumes, where it waits, what the
substrate offers that the loop leaves unused. The policymaker decides, per project,
what is measured and what the audit may see and do. Each measurement is done
by the audit session itself or, when the audit finds it mechanical, turned
into a script it keeps for later audits. Proposes changes to the policymaker and
changes nothing else. Judges how the loop uses its environment, never the
quality of the work (that is the evaluator).
_Avoid_: monitoring, telemetry

**Change gate**:
The verdict "not worse than what is accepted" that a piece of work must get
before it enters the main line. Issued by the evaluator or the owner, as the
setup map decides.
_Avoid_: review, merge check

**Setup baseline**:
The state of the loop's repository at the moment the setup map is closed and
the loop is armed, marked by the tag `setup-baseline` and checked with
`setup_roles.py validate --baseline setup-baseline` before arming. The engine returns the policy artifacts to
it when they are rolled back before any iteration has closed.

**Owner request**:
A question the loop puts to the owner, answerable only by them: a consent, a
proposed goal or goal gate, a confirmation of a result. The owner answers by
closing it; a notice only informs.
An unanswered optional access request leaves independent work running.
_Avoid_: ticket for the owner, approval

**Accepted limits**:
The bounds the owner has accepted for what roles and their profiles may do.
The policymaker widens roles within them on its own; beyond them, work waits for an
owner request or for the owner to move the limits.
_Avoid_: permissions, allowlist

## LabVIEW reading

**Reading fidelity**:
The agreement between the tool's representation of a LabVIEW artifact and independently established facts about
its elements, relationships and meaning.

**Grounded answer**:
An agent's answer supported by a verifiable location in the original LabVIEW artifact, rather than only by a claim
in the tool's export. Its correctness is assessed separately from reading fidelity.

**Benchmark readiness**:
The independently checked availability of a repeatable method with trustworthy expected answers, evaluation
separation, coverage accounting and baseline comparisons. It is not evidence that the tool itself works.

**Product**:
The tool enabling AI agents to read LabVIEW code, projects and all artifacts like ordinary code.
Preparing its environment, examples and verification method precedes product implementation.
